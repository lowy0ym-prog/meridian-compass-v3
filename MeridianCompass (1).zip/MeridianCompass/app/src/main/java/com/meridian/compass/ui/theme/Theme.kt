package com.meridian.compass.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

private val DarkColors = darkColorScheme(
    primary = SamsungBlue,
    secondary = AccentAmber,
    background = OneUiBlack,
    surface = OneUiSurfaceDark,
    surfaceVariant = OneUiSurfaceDarkElevated,
    onPrimary = Color.White,
    onBackground = OffWhite,
    onSurface = OffWhite,
    error = DangerRed
)

private val LightColors = lightColorScheme(
    primary = SamsungBlueDim,
    secondary = Color(0xFFEF8A1E),
    background = OffWhite,
    surface = Color(0xFFFFFFFF),
    onPrimary = Color.White,
    onBackground = Color(0xFF191A1C),
    onSurface = Color(0xFF191A1C),
    error = DangerRed
)

// One UI leans on very generous corner rounding everywhere — cards, sheets, buttons — far more
// than default Material3. This shape scale is the single biggest lever for that look.
private val OneUiShapes = Shapes(
    extraSmall = RoundedCornerShape(12.dp),
    small = RoundedCornerShape(16.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(26.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

enum class AppThemeMode { LIGHT, DARK, SYSTEM }

@Composable
fun MeridianTheme(
    themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    content: @Composable () -> Unit
) {
    val darkTheme = when (themeMode) {
        AppThemeMode.LIGHT -> false
        AppThemeMode.DARK -> true
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val colorScheme = if (darkTheme) DarkColors else LightColors
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }
    MaterialTheme(
        colorScheme = colorScheme,
        typography = MeridianTypography,
        shapes = OneUiShapes,
        content = content
    )
}

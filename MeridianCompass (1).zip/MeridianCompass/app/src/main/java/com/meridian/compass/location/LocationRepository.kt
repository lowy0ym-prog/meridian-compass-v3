package com.meridian.compass.location

import android.annotation.SuppressLint
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Looper
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.callbackFlow

data class LocationState(
    val latitude: Double? = null,
    val longitude: Double? = null,
    val horizontalAccuracyMeters: Float? = null,
    val gpsAltitudeMeters: Double? = null,
    val barometricAltitudeMeters: Double? = null,
    val hasFix: Boolean = false,
    val activeProvider: String? = null
) {
    /** Best available altitude estimate: prefer barometer-derived, fall back to GPS. */
    val bestAltitudeMeters: Double?
        get() = barometricAltitudeMeters ?: gpsAltitudeMeters

    /** True when we only have a single-source estimate and should flag it as approximate. */
    val altitudeIsRoughEstimate: Boolean
        get() = barometricAltitudeMeters == null && (horizontalAccuracyMeters == null || horizontalAccuracyMeters > 15f)
}

/**
 * Location and altitude source for the app.
 *
 * IMPORTANT: this deliberately uses Android's built-in [LocationManager] (GPS_PROVIDER /
 * NETWORK_PROVIDER, plus FUSED_PROVIDER on Android 12+ where the OS itself exposes one) rather
 * than Google Play Services' FusedLocationProviderClient. That keeps location working on
 * devices with no Google Play Services installed/enabled at all (e.g. GrapheneOS, Play-less
 * Android builds, or a device with GMS disabled) — a hard requirement for this app.
 *
 * Altitude is refined with the barometer (pressure sensor) when present, which is standard
 * Android hardware access with no Play Services involvement either.
 */
class LocationRepository(private val context: Context) {

    private val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val pressureSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE)

    private val _state = MutableStateFlow(LocationState())
    val state: StateFlow<LocationState> = _state

    private val seaLevelReferenceHPa = 1013.25f // standard atmosphere reference for barometric altitude

    fun hasBarometer(): Boolean = pressureSensor != null

    private val pressureListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            val pressureHpa = event.values[0]
            val altitude = SensorManager.getAltitude(seaLevelReferenceHPa, pressureHpa)
            _state.value = _state.value.copy(barometricAltitudeMeters = altitude.toDouble())
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    fun startBarometer() {
        pressureSensor?.let {
            sensorManager.registerListener(this.pressureListener, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    fun stopBarometer() {
        sensorManager.unregisterListener(pressureListener)
    }

    /**
     * Emits location updates from whichever standard Android providers are available on this
     * device (GPS for best accuracy outdoors, network-based as a fallback / indoors, and the
     * OS-level fused provider on Android 12+). Silently skips any provider that is disabled or
     * not present — the app degrades gracefully rather than requiring a specific one.
     */
    @SuppressLint("MissingPermission")
    fun locationUpdates() = callbackFlow<LocationState> {
        val listener = LocationListener { location -> emitLocation(location) }

        val candidateProviders = buildList {
            add(LocationManager.GPS_PROVIDER)
            add(LocationManager.NETWORK_PROVIDER)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                add(LocationManager.FUSED_PROVIDER)
            }
        }

        val registeredProviders = mutableListOf<String>()
        for (provider in candidateProviders) {
            if (locationManager.allProviders.contains(provider) && isProviderUsable(provider)) {
                runCatching {
                    locationManager.requestLocationUpdates(provider, 1000L, 0f, listener, Looper.getMainLooper())
                    registeredProviders += provider
                }
            }
        }

        // Seed with the best last-known fix immediately so the UI isn't blank while waiting
        // for the first fresh update.
        registeredProviders
            .mapNotNull { provider -> runCatching { locationManager.getLastKnownLocation(provider) }.getOrNull() }
            .maxByOrNull { it.time }
            ?.let { emitLocation(it) }

        awaitClose { locationManager.removeUpdates(listener) }
    }

    private fun isProviderUsable(provider: String): Boolean = try {
        locationManager.isProviderEnabled(provider)
    } catch (e: Exception) {
        false
    }

    private fun emitLocation(location: Location) {
        val updated = _state.value.copy(
            latitude = location.latitude,
            longitude = location.longitude,
            horizontalAccuracyMeters = if (location.hasAccuracy()) location.accuracy else null,
            gpsAltitudeMeters = if (location.hasAltitude()) location.altitude else null,
            hasFix = true,
            activeProvider = location.provider
        )
        _state.value = updated
    }
}

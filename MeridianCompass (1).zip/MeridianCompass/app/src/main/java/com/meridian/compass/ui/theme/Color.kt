package com.meridian.compass.ui.theme

import androidx.compose.ui.graphics.Color

// Samsung One UI leans on a true-black dark mode with a single vivid signature accent (Samsung's
// own uses a signature blue) rather than the teal/navy palette from the first pass — mixing that
// with the reference app's dark, high-contrast navigation screens.
val OneUiBlack = Color(0xFF0A0A0C)
val OneUiSurfaceDark = Color(0xFF19191C)
val OneUiSurfaceDarkElevated = Color(0xFF232326)
val SamsungBlue = Color(0xFF3A8CFF)
val SamsungBlueDim = Color(0xFF1C5FCC)
val AccentAmber = Color(0xFFFFB74D)
val OffWhite = Color(0xFFF4F6F8)
val DangerRed = Color(0xFFFF5B54)

// Legacy names kept as aliases so any stray reference still resolves.
val DeepNavy = OneUiBlack
val DeepNavyLight = OneUiSurfaceDark
val AccentTeal = SamsungBlue
val DialRingLight = Color(0xFFD8DEE8)
val DialRingDark = Color(0xFF2B2B30)

package com.meridian.compass.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Waypoint::class, TrailPoint::class, Trail::class], version = 3, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun waypointDao(): WaypointDao
    abstract fun trailDao(): TrailDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "meridian_waypoints.db"
                )
                    // App is pre-release; rather than hand-write a migration for the new
                    // category/photoPath columns, we accept clearing local test data on schema
                    // bumps for now. Revisit with a real Migration before shipping to real users.
                    .fallbackToDestructiveMigration()
                    .build().also { INSTANCE = it }
            }
        }
    }
}
